<?php
return [
    'zoom_level'           => 13,
    'detail_zoom_level'    => 20,
    'map_center_latitude'  => env('MAP_CENTER_LATITUDE', '5.549568149890185'),
    'map_center_longitude' => env('MAP_CENTER_LONGITUDE', '95.31488294181023'),
    // UNTUK MENGAMBIL LATITUDE DAN LONGITUDE SILAHKAN LAKUKAN SECARA MANUAL ATAU AKSES HALAMAN CREATE KEMUDIAN
    // GESER KE LOKASI YANG DI INGINKAN
];
