

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('data vaksin')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Tanggal</label>
                            <input name="tanggal" type="date" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Kecamatan</label>
                            <select class="form-select" name="tematik_id" required>
                                <option value="">Pilih Kecamatan</option>
                                <?php $__currentLoopData = $tematik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kecamatan->id); ?>"><?php echo e($kecamatan->kecamatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Nakes</label>
                            <input name="nakes" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Petugas Publik</label>
                            <input name="petugas_publik" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Lansia</label>
                            <input name="lansia" type="number" class="form-control" required>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kelompok</label>
                            <select class="form-select" name="kelompok" required>
                                <option value="">Pilih Kelompok</option>
                                <option value="Target">Target</option>
                                <option value="Dosis 1">Dosis 1</option>
                                <option value="Dosis 2">Dosis 2</option>
                                <option value="Dosis 3">Dosis 3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Desa</label>
                            <select class="form-select" name="desa_id" required>
                                <option value="">Pilih Desa</option>
                                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->desa); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Masyarakat Umum</label>
                            <input name="masyarakat_umum" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Remaja</label>
                            <input name="remaja" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>usia 6-11 tahun</label>
                            <input name="usia" type="number" class="form-control" required>
                        </div>

                    </div>
                </div>
                <button class="btn float-end text-white" style="background-color: #417D7A" type="submit">Tambah</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/tambah_data.blade.php ENDPATH**/ ?>