<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <?php echo notifyCss(); ?>
    <?php echo notifyJs(); ?>

    <!-- Styles -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('storage/css/adminlte.min.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css"
        integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/v/dt/dt-1.11.4/fh-3.2.1/sc-2.0.5/datatables.min.css" />

    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.4/fh-3.2.1/sc-2.0.5/datatables.min.js">
    </script>

    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
    <div id="app">
        <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="background-color: #EDE6DB">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="<?php echo e(route('Data user')); ?>" role="button"><i
                            class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href=<?php echo e(route('Data user')); ?> class="nav-link">Home</a>
                </li>

            </ul>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">

                    <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                    </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#drop" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div id="drop" class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
                </li>
            </ul>
        </nav>
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
            <aside class="main-sidebar sidebar-dark-primary elevation-4 position-fixed" style="background-color: #417D7A">
                <!-- Brand Logo -->
                <a href="<?php echo e(route('Data user')); ?>" class="brand-link">

                    <h2 class="brand-text font-weight-light">Dinas Kesehatan <br> Kota Banda Aceh</>
                </a>

                <!-- Sidebar -->
                <div class="sidebar">
                    <!-- Sidebar user panel (optional) -->
                    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                        <div class="info text-white">
                            <?php echo e(Auth::user()->name); ?>

                        </div>
                    </div>

                    <!-- Sidebar Menu -->
                    <nav class="mt-2">
                        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                            data-accordion="false">

                            <?php if(auth()->user()->level == 'admin'): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('home')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-th"></i>
                                        <p>
                                            Dashboard
                                        </p>
                                    </a>
                                </li>

                                <li class="nav-item">
                                    <a data-bs-toggle="collapse" href="#maps"
                                        class="nav-link btn bg-transparent text-white text-start w-100"
                                        aria-controls="manajemen" role="button" aria-expanded="true">
                                        <i class="nav-icon fa-solid fa-map"></i>
                                        Maps
                                        <i class="fas fa-sort-down float-end"></i>
                                    </a>

                                    <div class="collapse " id="maps" style="">
                                        <ul class="nav ms-4 ps-3">
                                            <li class="nav-item w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('maps lokasi')); ?>">Lokasi
                                                    Vaksinasi</a>
                                            </li>
                                            <li class="nav-item  w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('maps desa')); ?>">Desa</a>
                                            </li>
                                            <li class="nav-item w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('maps')); ?>">Kecamatan</a>
                                            </li>
                                            <li class="nav-item w-100 ">
                                                <a class="dropdown-item" href="<?php echo e(route('Rute')); ?>">Rute</a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a data-bs-toggle="collapse" href="#data"
                                        class="nav-link btn bg-transparent text-white text-start w-100"
                                        aria-controls="manajemen" role="button" aria-expanded="true">
                                        <i class="nav-icon fa-solid fa-database"></i>
                                        Data
                                        <i class="fas fa-sort-down float-end"></i>
                                    </a>

                                    <div class="collapse " id="data" style="">
                                        <ul class="nav ms-4 ps-3">
                                            <li class="nav-item w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('halaman data')); ?>"> Data
                                                    Vaksinasi</a>
                                            </li>
                                            <li class="nav-item  w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('halaman data2')); ?>">Data Lokasi
                                                    Vaksinasi</a>
                                            </li>
                                            <li class="nav-item w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('halaman desa')); ?>">Data
                                                    Desa</a>
                                            </li>
                                            <li class="nav-item w-100">
                                                <a class="dropdown-item" href="<?php echo e(route('halaman tematik')); ?>">Data
                                                    Kecamatan</a>
                                            </li>
                                            <li class="nav-item w-100 ">
                                                <a class="dropdown-item" href="<?php echo e(route('rumah sakit')); ?>">Data User</a>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('rs dashboard')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-th"></i>
                                        <p>
                                            Dashboard
                                        </p>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('verif')); ?>" class="nav-link">
                                        <i class="nav-icon fas fa-th"></i>
                                        <p>
                                            Verifikasi
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('panduan')); ?>" class="nav-link">
                                    <i class="nav-icon fa-solid fa-book"></i>
                                    <p>
                                        Panduan
                                    </p>
                                </a>
                            </li>
                    </nav>
                    <!-- /.sidebar-menu -->
                </div>
                <!-- /.sidebar -->
            </aside>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <main class="mt-4">
                <?php else: ?>
                    <main class="content-wrapper mt-4">
                        <?php endif; ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </main>
            </div>
            <script src="<?php echo e(asset('js/app.js')); ?>"></script>
            <?php echo $__env->yieldPushContent('DataTables'); ?>
            <?php echo $__env->yieldPushContent('scripts'); ?>
        </body>

        </html>
<?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/layouts/app.blade.php ENDPATH**/ ?>