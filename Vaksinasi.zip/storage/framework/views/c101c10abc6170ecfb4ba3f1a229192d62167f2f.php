


<section class="w-100" style="background-color: #4F8A8B">
    <a href="<?php echo e(route('login')); ?>" class="text-decoration-none text-white m-4 py-1 btn btn-outline-light me-2">
        <h4>Log in</h4>
    </a>
    <a href="<?php echo e(route('Data user')); ?>" class="text-decoration-none text-white m-4 py-1 me-2 btn">
        <h4>Home</h4>
    </a>
    <a href="<?php echo e(route('Rute')); ?>" class="text-decoration-none text-white m-4 py-1 me-2 btn">
        <h4>Rute</h4>
    </a>
    <a href="<?php echo e(route('panduan')); ?>" class="text-decoration-none text-white m-4 py-1 me-2 btn"
        style="border-bottom:1px solid white;">
        <h4>Panduan</h4>
    </a>
    <a href="<?php echo e(route('pendaftaran')); ?>" class="text-decoration-none text-white m-4 py-1 me-2 btn">
        <h4>Daftar Vaksinasi</h4>
    </a>
</section>
<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="card p-4">
            <div class="row">
                <div class="col">
                    <div class="row">
                        <div class="col-md-1">
                            <h4 class="bg-info text-white rounded-circle px-2" style="width: fit-content">
                                1
                            </h4>
                        </div>
                        <div class="col-md-6">
                            Text
                        </div>
                    </div>
                    <img width="200" src="<?php echo e(asset('storage/img/left-image.png')); ?>" alt="">
                </div>
                <div class="col">
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/panduan.blade.php ENDPATH**/ ?>