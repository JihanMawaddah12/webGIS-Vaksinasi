

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('update rumahsakit')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Rumah Sakit</label>
                            <select name="halaman_data2_id" id="" required class="form-control">
                                <option value="">--Pilih Rumah Sakit--</option>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"
                                        <?php echo e($user->rm->halaman_data2_id == $item->id ? 'selected' : ''); ?>>
                                        <?php echo e($item->lokasi); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input name="email" type="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                            <input name="user_id" type="hidden" class="form-control" value="<?php echo e($user->id); ?>">
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input name="password" type="text" class="form-control">
                        </div>
                    </div>
                </div>
                <button class="btn float-end mt-4 text-white" type="submit"
                    style="background-color: #1D5C63">Update</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/edit_rumahsakit.blade.php ENDPATH**/ ?>