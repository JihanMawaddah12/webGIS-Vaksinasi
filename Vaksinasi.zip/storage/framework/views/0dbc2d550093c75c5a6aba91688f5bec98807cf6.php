

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('post rumahsakit')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Rumah Sakit</label>
                            <select name="halaman_data2_id" id="" required class="form-control">
                                <option value="">--Pilih Rumah Sakit--</option>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->lokasi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input name="email" type="email" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input name="password" type="text" class="form-control" required>
                        </div>
                    </div>
                </div>
                <button class="btn float-end text-white" style="background-color: #417D7A" type="submit">Tambah</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/tambah_rumahsakit.blade.php ENDPATH**/ ?>