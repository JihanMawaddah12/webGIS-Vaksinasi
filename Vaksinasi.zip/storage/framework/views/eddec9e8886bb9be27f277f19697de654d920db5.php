

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="card p-4">
            <form action="<?php echo e(route('update data', ['id' => $id])); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kecamatan</label>
                            <select class="form-select" name="tematik_id" required>
                                <option value="">Pilih Kecamatan</option>
                                <?php $__currentLoopData = $tematik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($kecamatan->id == $data->tematik->id ? 'selected' : ''); ?>

                                        value="<?php echo e($kecamatan->id); ?>"><?php echo e($kecamatan->kecamatan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Kelompok</label>
                            <select class="form-select" name="kelompok" required>
                                <option value="">Pilih kelompok</option>
                                <option <?php echo e($data->Kelompok == 'Target' ? 'selected' : ''); ?> value="Target">Target
                                </option>
                                <option <?php echo e($data->Kelompok == 'Dosis 1' ? 'selected' : ''); ?> value="Dosis 1">Dosis
                                    1</option>
                                <option <?php echo e($data->Kelompok == 'Dosis 2' ? 'selected' : ''); ?> value="Dosis 2">Dosis
                                    2</option>
                                <option <?php echo e($data->Kelompok == 'Dosis 3' ? 'selected' : ''); ?> value="Dosis 3">Dosis
                                    3</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Nakes</label>
                            <input value="<?php echo e($data->nakes); ?>" name="nakes" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Petugas Publik</label>
                            <input value="<?php echo e($data->petugas_publik); ?>" name="petugas_publik" type="number"
                                class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Tanggal</label>
                            <input name="tanggal" type="date" class="form-control" value="<?php echo e($data->tanggal); ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                         <div class="form-group">
                             
                            <label>Desa</label>
                            <select class="form-select" name="desa_id" required>
                         
                                <?php $__currentLoopData = $desa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($data->desa ? $item->id == $data->desa->id ? 'selected' : '':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->desa); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Lansia</label>
                            <input value="<?php echo e($data->lansia); ?>" name="lansia" type="number" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Masyarakat Umum</label>
                            <input value="<?php echo e($data->masyarakat_umum); ?>" name="masyarakat_umum" type="number"
                                class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label>Remaja</label>
                            <input value="<?php echo e($data->remaja); ?>" name="remaja" type="number" class="form-control" required>
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary float-end mt-4" type="submit">Simpan</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/edit.blade.php ENDPATH**/ ?>