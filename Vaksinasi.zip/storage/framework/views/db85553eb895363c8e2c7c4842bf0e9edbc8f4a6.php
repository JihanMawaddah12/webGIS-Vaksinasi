

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box" style="background-color:#D4ECDD">
                    <div class="inner">
                        <h3><?php echo e($target); ?></h3>

                        <p>Sasaran Vaksinasi</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box text-white" style="background-color:rgb(65, 125, 122)">
                    <div class="inner">
                        <div class="row">
                            <div class="col">
                                <h3><?php echo e($dosis1); ?></h3>
                            </div>
                            <div class="col">
                                <h3 class="text-end">
                                    <?php echo e(number_format((float) ($dosis1 / $target) * 100, 2, '.', '')); ?>%
                                </h3>
                            </div>
                        </div>
                        <p>Total Vaksinasi Dosis 1</p>

                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box text-white" style="background-color:rgb(29, 92, 99)">
                    <div class="inner">
                        <div class="row">
                            <div class="col">
                                <h3><?php echo e($dosis2); ?></h3>
                            </div>
                            <div class="col">
                                <h3 class="text-end">
                                    <?php echo e(number_format((float) ($dosis2 / $target) * 100, 2, '.', '')); ?>%
                                </h3>
                            </div>
                        </div>
                        <p>Total Vaksinasi Dosis 2</p>

                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <div class="small-box text-white" style="background-color:rgb(26, 60, 64)">
                    <div class="inner">
                        <div class="row">
                            <div class="col">
                                <h3><?php echo e($dosis3); ?></h3>
                            </div>
                            <div class="col">
                                <h3 class="text-end">
                                    <?php echo e(number_format((float) ($dosis3 / $target) * 100, 2, '.', '')); ?>%
                                </h3>
                            </div>
                        </div>
                        <p>Total Vaksinasi Dosis 3</p>

                    </div>
                </div>
            </div>
            <!-- ./col -->
        </div>

        <div class="mb-2">
            <div class="row">

                <section class="col-lg-7 connectedSortable">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-chart-pie mr-1"></i>
                                Grafik
                            </h3>

                            <div class="card-tools mx-2">
                                <form action="<?php echo e(route('home')); ?>" method="get" id="form-graph">
                                    <select class="form-control" id="kecamatan">
                                        <option disabled selected value="">--Pilih Kecamatan--</option>
                                        <?php $__currentLoopData = $tematik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e($state == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->kecamatan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </form>
                            </div>
                        </div><!-- /.card-header -->
                        <div class="card-body" style="background-color: #D4ECDD">
                            <?php if($state): ?>
                                <div class="card-tools">
                                    <ul class="nav nav-pills ml-auto">
                                        <li class="nav-item">
                                            <a class="nav-link active" onclick="return state = 'grafik1'"
                                                href="#grafik1-button" data-bs-toggle="tab">Dosis
                                                1</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" onclick="return state = 'grafik2'"
                                                href="#grafik2-button" data-bs-toggle="tab">Dosis
                                                2</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" onclick="return state = 'grafik3'"
                                                href="#grafik3-button" data-bs-toggle="tab">Dosis
                                                3</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="tab-content p-0">
                                    <!-- Morris chart - Sales -->
                                    <div class="chart tab-pane active" id="grafik1-button"
                                        style="position: relative; height: 300px;">
                                        <canvas id="grafik1" height="300" style="height: 300px;"></canvas>
                                    </div>
                                    <div class="chart tab-pane" id="grafik2-button"
                                        style="position: relative; height: 300px;">
                                        <canvas id="grafik2" height="300" style="height: 300px;"></canvas>
                                    </div>
                                    <div class="chart tab-pane" id="grafik3-button"
                                        style="position: relative; height: 300px;">
                                        <canvas id="grafik3" height="300" style="height: 300px;"></canvas>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div><!-- /.card-body -->
                    </div>
                </section>
                <section class="col-lg-5 ">
                    <div class="card" style="background-color: #D4ECDD">
                        <div class="card-header border-0">
                            <h3 class="card-title">
                                <i class="fas fa-map-marker-alt mr-1"></i>
                                Maps
                            </h3>

                        </div>
                        <div class="card-body">
                            <div id="map" style="height: 350px; width: 100%;"></div>
                        </div>

                    </div>
                </section>

            </div>
        </div>

        <div class="row">
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <br>
                <div class="small-box text-white" style="background-color:#152D35">
                    <h4>Dosis Terendah (Kecamatan)</h4>
                    <hr class="text-white bg-white" />
                    <div class="inner">
                        <h4>Dosis 1</h4>
                        <h6>Kecamatan <?php echo e($krendah1->tematik->kecamatan); ?></h6>
                        <h6>Jumlah <?php echo e($krendah1->total); ?></h6>
                        <h3>
                            <?php echo e($krpersen1 ? number_format((float) ($krendah1->total / $krpersen1) * 100, 2, '.', '') : 0); ?>%
                            </h6>
                            <hr class="text-white bg-white" />
                            <h4>Dosis 2</h4>
                            <h6>Kecamatan <?php echo e($krendah2->tematik->kecamatan); ?></h6>
                            <h6>Jumlah <?php echo e($krendah2->total); ?></h6>
                            <h3>
                                <?php echo e($krpersen2 ? number_format((float) ($krendah2->total / $krpersen2) * 100, 2, '.', '') : 0); ?>%
                                </h6>
                                <hr class="text-white bg-white" />
                                <h4>Dosis 3</h4>
                                <h6>Kecamatan <?php echo e($krendah3->tematik->kecamatan); ?></h6>
                                <h6>Jumlah <?php echo e($krendah3->total); ?></h6>
                                <h3>
                                    <?php echo e($krpersen3 ? number_format((float) ($krendah3->total / $krpersen3) * 100, 2, '.', '') : 0); ?>%
                                    </h6>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <br>
                <div class="small-box text-black" style="background-color:#D4ECDD">
                    <h4>Dosis Tertinggi<br> (Kecamatan)</h4>
                    <hr class="text-white bg-green" />
                    <div class="inner">
                        <h4>Dosis 1</h4>
                        <h6>Kecamatan <?php echo e($ktinggi1->tematik->kecamatan); ?></h6>
                        <h6>Jumlah <?php echo e($ktinggi1->total); ?></h6>
                        <h3>
                            <?php echo e($ktpersen1 ? number_format((float) ($ktinggi1->total / $ktpersen1) * 100, 2, '.', '') : 0); ?>%
                        </h3>
                        <hr class="text-white bg-green" />
                        <h4>Dosis 2</h4>
                        <h6>Kecamatan <?php echo e($ktinggi2->tematik->kecamatan); ?></h6>
                        <h6>Jumlah <?php echo e($ktinggi2->total); ?></h6>
                        <h3>
                            <?php echo e($ktpersen2 ? number_format((float) ($ktinggi2->total / $ktpersen2) * 100, 2, '.', '') : 0); ?>%
                        </h3>
                        <hr class="text-white bg-green" />
                        <h4>Dosis 3</h4>
                        <h6>Kecamatan <?php echo e($ktinggi3->tematik->kecamatan); ?></h6>
                        <h6>Jumlah <?php echo e($ktinggi3->total); ?></h6>
                        <h3>
                            <?php echo e($ktpersen3 ? number_format((float) ($ktinggi3->total / $ktpersen3) * 100, 2, '.', '') : 0); ?>%
                        </h3>
                    </div>
                </div>
            </div>


            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <br>
                <div class="small-box text-white" style="background-color:rgb(26, 60, 64)">
                    <h4>Dosis Terendah <br>(Desa)</h4>
                    <hr class="text-white bg-white" />
                    <div class="inner">
                        <h4>Dosis 1</h4>
                        <h6>Desa <?php echo e($drendah1->desa->desa); ?></h6>
                        <h6>Jumlah <?php echo e($drendah1->total); ?></h6>
                        <h3>
                            <?php echo e($drpersen1 ? number_format((float) ($drendah1->total / $drpersen1) * 100, 2, '.', '') : 0); ?>%
                            </h6>
                            <hr class="text-white bg-white" />
                            <h4>Dosis 2</h4>
                            <h6>Desa <?php echo e($drendah2->desa->desa); ?></h6>
                            <h6>Jumlah <?php echo e($drendah2->total); ?></h6>
                            <h3>
                                <?php echo e($drpersen2 ? number_format((float) ($drendah2->total / $drpersen2) * 100, 2, '.', '') : 0); ?>%
                                </h6>
                                <hr class="text-white bg-white" />
                                <h4>Dosis 3</h4>
                                <h6>Desa <?php echo e($drendah3->desa->desa); ?></h6>
                                <h6>Jumlah <?php echo e($drendah3->total); ?></h6>
                                <h3>
                                    <?php echo e($drpersen3 ? number_format((float) ($drendah3->total / $drpersen3) * 100, 2, '.', '') : 0); ?>%
                                    </h6>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-6">
                <!-- small box -->
                <br>
                <div class="small-box" style="background-color:#D4ECDD">
                    <h4>Dosis Tertinggi <br>(Desa)</h4>
                    <hr class="text-white bg-green" />
                    <div class="inner">
                        <h4>Dosis 1</h4>
                        <h6>Desa <?php echo e($dtinggi1->desa->desa); ?></h6>
                        <h6>Jumlah <?php echo e($dtinggi1->total); ?></h6>
                        <h3>
                            <?php echo e($dtpersen1 ? number_format((float) ($dtinggi1->total / $dtpersen1) * 100, 2, '.', '') : 0); ?>%
                            </h6>
                            <hr class="text-white bg-green" />
                            <h4>Dosis 2</h4>
                            <h6>Desa <?php echo e($dtinggi2->desa->desa); ?></h6>
                            <h6>Jumlah <?php echo e($dtinggi2->total); ?></h6>
                            <h3>
                                <?php echo e($dtpersen2 ? number_format((float) ($dtinggi2->total / $dtpersen2) * 100, 2, '.', '') : 0); ?>%
                                </h6>
                                <hr class="text-white bg-green" />
                                <h4>Dosis 3</h4>
                                <h6>Desa <?php echo e($dtinggi3->desa->desa); ?></h6>
                                <h6>Jumlah <?php echo e($dtinggi3->total); ?></h6>
                                <h3>
                                    <?php echo e($dtpersen3 ? number_format((float) ($dtinggi3->total / $dtpersen3) * 100, 2, '.', '') : 0); ?>%
                                    </h6>
                    </div>
                </div>
            </div>


            <!-- ./col -->
        </div>
        <div class="col-lg-6 col-6">

            <br>
            <div class="p-4 w-100 rounded shadow text-white" style="background-color:#417D7A">
                <h3>Tenaga Kesehatan</h3>
                <hr class="text-white bg-white" />
                <div class="inner">
                    <div class="row">
                        <div class="col">
                            <h4>Dosis 1</h4>
                            <h6>Jumlah <?php echo e($dosis1_nakes); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis1_nakes / $target_nakes) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                        <div class="col">
                            <h4>Dosis 2</h4>

                            <h6>Jumlah <?php echo e($dosis2_nakes); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis2_nakes / $target_nakes) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                        <div class="col">
                            <h4>Dosis 3</h4>
                            <h6>Jumlah <?php echo e($dosis3_nakes); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis3_nakes / $target_nakes) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="col-lg-6 col-6">
            <br>
            <div class="p-4 w-100 rounded shadow text-white" style="background-color:#1D5C63">
                <h2>Petugas Publik</h2>
                <hr class="text-white bg-white" />
                <div class="inner">
                    <div class="row">
                        <div class="col">
                            <h4>Dosis 1</h4>
                            <h6>Jumlah <?php echo e($dosis1_petugas); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis1_petugas / $target_petugas) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 2</h4>

                            <h6>Jumlah <?php echo e($dosis2_petugas); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis2_petugas / $target_petugas) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 3</h4>
                            <h6>Jumlah <?php echo e($dosis3_petugas); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis3_petugas / $target_petugas) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-6">
            <br>
            <div class="p-4 w-100 rounded shadow text-white" style="background-color:#1A3C40">
                <h2>Lansia</h2>
                <hr class="text-white bg-white" />
                <div class="inner">
                    <div class="row">
                        <div class="col">
                            <h4>Dosis 1</h4>
                            <h6>Jumlah <?php echo e($dosis1_lansia); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis1_lansia / $target_lansia) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 2</h4>

                            <h6>Jumlah <?php echo e($dosis2_lansia); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis2_lansia / $target_lansia) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 3</h4>
                            <h6>Jumlah <?php echo e($dosis3_lansia); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis3_lansia / $target_lansia) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-6">
            <br>
            <div class="p-4 w-100 rounded shadow text-white" style="background-color:#417D7A">
                <h2>Masyarakat</h2>
                <hr class="text-white bg-white" />
                <div class="inner">
                    <div class="row">
                        <div class="col">
                            <h4>Dosis 1</h4>
                            <h6>Jumlah <?php echo e($dosis1_masyarakat); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis1_masyarakat / $target_masyarakat) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 2</h4>

                            <h6>Jumlah <?php echo e($dosis2_masyarakat); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis2_masyarakat / $target_masyarakat) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 3</h4>
                            <h6>Jumlah <?php echo e($dosis3_masyarakat); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis3_masyarakat / $target_masyarakat) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-6">
            <br>
            <div class="p-4 w-100 rounded shadow text-white" style="background-color:#1D5C63">
                <h2>Remaja</h2>
                <hr class="text-white bg-white" />
                <div class="inner">
                    <div class="row">
                        <div class="col">
                            <h4>Dosis 1</h4>
                            <h6>Jumlah <?php echo e($dosis1_remaja); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis1_remaja / $target_remaja) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 2</h4>

                            <h6>Jumlah <?php echo e($dosis2_remaja); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis2_remaja / $target_remaja) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 3</h4>
                            <h6>Jumlah <?php echo e($dosis3_remaja); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis3_remaja / $target_remaja) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-6">
            <br>
            <div class="p-4 w-100 rounded shadow text-white" style="background-color:#1A3C40">
                <h2>Usia 6-11 tahun</h2>
                <hr class="text-white bg-white" />
                <div class="inner">
                    <div class="row">
                        <div class="col">
                            <h4>Dosis 1</h4>
                            <h6>Jumlah <?php echo e($dosis1_usia); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis1_usia / $target_usia) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 2</h4>

                            <h6>Jumlah <?php echo e($dosis2_usia); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis2_usia / $target_usia) * 100, 2, '.', '')); ?>%
                            </h3>
                        </div>
                        <div class="col">
                            <h4>Dosis 3</h4>
                            <h6>Jumlah <?php echo e($dosis3_usia); ?></h6>
                            <h3>
                                <?php echo e(number_format((float) ($dosis3_usia / $target_usia) * 100, 2, '.', '')); ?>%
                                </h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('styles'); ?>
        <!-- Leaflet CSS -->
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
            integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
            crossorigin="" />
        <style>
            .leaflet-control-attribution {
                display: none !important
            }

            .info {
                padding: 6px 8px;
                font: 14px/16px Arial, Helvetica, sans-serif;
                background: #EDE6DB;
                background: #EDE6DB;
                box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
                border-radius: 5px;
            }

            .info h4 {
                margin: 0 0 5px;
                color: #777;
            }

            .legend {
                text-align: left;
                line-height: 18px;
                color: #555;
            }

            .legend i {
                width: 18px;
                height: 18px;
                float: left;
                margin-right: 8px;
                opacity: 0.7;
            }

        </style>
    <?php $__env->stopSection(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"
                integrity="sha512-TW5s0IT/IppJtu76UbysrBH9Hy/5X41OTAbQuffZFU6lQ1rdcLHzpU5BzVvr/YFykoiMYZVWlr/PX1mDcfM9Qg=="
                crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $('#kecamatan').change(function() {
                window.location.href = '/home/' + this.value;
            });
        </script>
        <script>
            var labels = <?php echo json_encode($kec); ?>;
            const data = {
                labels: labels,
                datasets: [{
                    label: 'Dosis 1',
                    backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: <?php echo json_encode($jumlah); ?>,

                }],
            };
            const plugin = {
                id: 'custom_canvas_background_color1',
                beforeDraw: (chart) => {
                    const ctx = chart.canvas.getContext('2d');
                    ctx.save();
                    ctx.globalCompositeOperation = 'destination-over';
                    ctx.fillStyle = 'white';
                    ctx.fillRect(0, 0, chart.width, chart.height);
                    ctx.restore();
                }
            };
            const config = {
                type: 'line',
                data: data,
                plugins: [plugin],
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: 0,
                            ticks: {
                                stepSize: 5
                            }
                        }
                    }
                }
            };
            const myChart = new Chart(
                document.getElementById('grafik1'),
                config
            );
        </script>
        <script>
            var labels2 = <?php echo json_encode($kec2); ?>;
            const data2 = {
                labels: labels2,
                datasets: [{
                    label: 'Dosis 2',
                    backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: <?php echo json_encode($jumlah2); ?>,

                }],
            };
            const plugin2 = {
                id: 'custom_canvas_background_color2',
                beforeDraw: (chart) => {
                    const ctx = chart.canvas.getContext('2d');
                    ctx.save();
                    ctx.globalCompositeOperation = 'destination-over';
                    ctx.fillStyle = 'white';
                    ctx.fillRect(0, 0, chart.width, chart.height);
                    ctx.restore();
                }
            };
            const config2 = {
                type: 'line',
                data: data2,
                plugins: [plugin2],
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: 0,
                            ticks: {
                                stepSize: 5
                            }
                        }
                    }
                }
            };

            const myChart2 = new Chart(
                document.getElementById('grafik2'),
                config2
            );
        </script>
        <script>
            var labels3 = <?php echo json_encode($kec3); ?>;
            const data3 = {
                labels: labels3,
                datasets: [{
                    label: 'Dosis 3',
                    backgroundColor: 'rgb(255, 99, 132)',
                    borderColor: 'rgb(255, 99, 132)',
                    data: <?php echo json_encode($jumlah3); ?>,

                }],
            };
            const plugin3 = {
                id: 'custom_canvas_background_color3',
                beforeDraw: (chart) => {
                    const ctx = chart.canvas.getContext('2d');
                    ctx.save();
                    ctx.globalCompositeOperation = 'destination-over';
                    ctx.fillStyle = 'white';
                    ctx.fillRect(0, 0, chart.width, chart.height);
                    ctx.restore();
                }
            };
            const config3 = {
                type: 'line',
                data: data3,
                plugins: [plugin3],
                options: {
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            min: 0,
                            ticks: {
                                stepSize: 5
                            }
                        }
                    }
                }
            };
            const myChart3 = new Chart(
                document.getElementById('grafik3'),
                config3
            );
        </script>
        <!-- Leaflet JavaScript -->
        <!-- Make sure you put this AFTER Leaflet's CSS -->
        <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
                integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
                crossorigin="">
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet-ajax/2.1.0/leaflet.ajax.min.js"
                integrity="sha512-Abr21JO2YqcJ03XGZRPuZSWKBhJpUAR6+2wH5zBeO4wAw4oksr8PRdF+BKIRsxvCdq+Mv4670rZ+dLnIyabbGw=="
                crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script type="text/javascript">
            var s = [5.554630942893766, 95.31709742351293];
            var color = <?php echo json_encode($color); ?>;
            var datamap = <?php echo json_encode($data); ?>

            var map = L.map('map').setView(
                s, 11
            );


            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);


            var info = L.control();

            info.onAdd = function(map) {
                this._div = L.DomUtil.create('div', 'info');
                this.update();
                return this._div;
            };
            //menampilkan pop up info tematik
            info.update = function(props) {
                this._div.innerHTML = '<h4>Kecamatan</h4>' + (props ?
                    '<b>' + props.NAMOBJ + '</b><br />' + props.MhsSIF + ' orang' :
                    'Gerakkan mouse Anda');
            };

            info.addTo(map);

            function style(feature) {
                return {
                    weight: 2,
                    opacity: 1,
                    color: 'black',
                    dashArray: '3',
                    fillOpacity: 0.9,
                    fillColor: color[feature.properties.NAMOBJ]
                };

            }
            //memunculkan highlight pada peta
            function highlightFeature(e) {
                var layer = e.target;

                layer.setStyle({
                    weight: 5,
                    color: '#666',
                    dashArray: '',
                    fillOpacity: 0.7
                });

                if (!L.Browser.ie && !L.Browser.opera) {
                    layer.bringToFront();
                }

                info.update(layer.feature.properties);
            }
            for (var i = 0; i < datamap.length; i++) {
                marker = new L.marker([datamap[i][1], datamap[i][2]])
                    .bindPopup(datamap[i][0])
                    .addTo(map);
            }
            var geojson;

            function resetHighlight(e) {
                geojsonLayer.resetStyle(e.target);
                info.update();
            }

            function zoomToFeature(e) {
                map.fitBounds(e.target.getBounds());
            }

            function onEachFeature(feature, layer) {
                layer.on({
                    mouseover: highlightFeature,
                    mouseout: resetHighlight,
                    click: zoomToFeature
                });
            }
            var geojsonLayer = new L.GeoJSON.AJAX(<?php echo json_encode($geofile); ?>, {
                style: style,
                onEachFeature: onEachFeature
            });
            geojsonLayer.addTo(map);

            var legend = L.control({
                position: 'bottomright'
            });

            //pemanggilan legend
            legend.onAdd = function(map) {

                var div = L.DomUtil.create('div', 'info legend'),
                    grades = [0, 12, 25, 37, 50, 62, 75, 87], //pretty break untuk 8
                    labels = [],
                    from, to;

                for (var i = 0; i < grades.length; i++) {
                    from = grades[i];
                    to = grades[i + 1];

                    labels.push(
                        '<i style="background:' + getColor(from + 1) + '"></i> ' +
                        from + (to ? '&ndash;' + to : '+'));
                }

                div.innerHTML = '<h4>Legenda:</h4><br>' + labels.join('<br>');
                return div;
            };

            legend.addTo(map);
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Vaksinasi\resources\views/home.blade.php ENDPATH**/ ?>